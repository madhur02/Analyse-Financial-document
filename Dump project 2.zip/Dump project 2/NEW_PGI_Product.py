﻿"""
Created on Mon May 21 13:14:10 2018
modified author: G753903
principal Financial group
"""

import pandas as pd
import warnings
warnings.filterwarnings('ignore')
import os
import re
from docx import Document

path = "C:\\Users\\J554696\\Desktop\\PGI_Product_Team\\"


def read_excel_sheet(file_name):
    """
    @@ function read the excel file and rename the column name on the basis of
    sheet name and column name and return as a list of all sheet and content
    and company header
    """
    file_name = path+file_name
    excel = pd.ExcelFile(file_name)
    all_sheets = excel.sheet_names
    main_dataFrame = []
    file_content = []
    header_columns = []

    for index , sheet_name in enumerate( all_sheets):
        content_sheet = excel.parse(sheet_name)
        if index == 0:
            header_columns =  (content_sheet["Investment"].values.tolist())
        file_content.append([sheet_name,content_sheet])

    for sheet_name_content in file_content:
        sheet_name    = sheet_name_content[0]
        content_sheet_dataFrame = sheet_name_content[1]

        for col_name in content_sheet_dataFrame.columns:
            content_sheet_dataFrame = content_sheet_dataFrame.rename(columns={col_name: sheet_name + '_' + col_name})
        content_sheet_dataFrame =  content_sheet_dataFrame.transpose()
        new_header =content_sheet_dataFrame.iloc[0]
        content_sheet_dataFrame = content_sheet_dataFrame[1:]
        content_sheet_dataFrame.columns = new_header
        for column in content_sheet_dataFrame.columns:
            content_sheet_dataFrame[column] = pd.to_numeric(content_sheet_dataFrame[column], errors='coerce')
        content_sheet_dataFrame= content_sheet_dataFrame.fillna(0)

        for i in content_sheet_dataFrame.columns:
            content_sheet_dataFrame[i + '_diff_percentage'] = ((content_sheet_dataFrame[i] - content_sheet_dataFrame[content_sheet_dataFrame.columns[0]])*100) // content_sheet_dataFrame[content_sheet_dataFrame.columns[0]]
            content_sheet_dataFrame = content_sheet_dataFrame.fillna(0)
        main_dataFrame.append(content_sheet_dataFrame)

    return main_dataFrame , header_columns


def renaming_rows_name(File_name,header_columns):
    """
    function take input as a csv file and company header column
    read this csv and check column value and and replace it by our nomenclature
    and take only required header or columns.
    """

    print (File_name[:-4] + "_Output1.csv")
    output_df = pd.read_csv(File_name[:-4] + "_Output1.csv" )

    new_data = []
    for index , row in output_df.iterrows():

        cell_value = row[0]
        tmp = []

        cell_value = "_".join(cell_value.lower().split(" "))

        if '1_year' in cell_value:
            tmp.append('1_year')
        elif '3_year' in cell_value:
            tmp.append('3_year')
        elif '5_Year' in cell_value:
            tmp.append('5_Year')
        elif 'sharpe_ratio' in cell_value:
            tmp.append('sharpe_ratio')
        elif 'std_dev' in cell_value:
            tmp.append('std_dev')
        elif 'ranking' in cell_value:
            tmp.append('ranking')
        elif 'alpha' in cell_value:
            tmp.append('alpha')

        elif 'max_drawdown' in cell_value:

            tmp.append('max_drawdown')

        elif 'shortest_recovery_time' in cell_value: # shortest recoverytime

            tmp.append('shortest_recovery_time')

        elif 'recovery_time' in cell_value: # shortest recoverytime

            tmp.append('recovery_time')

        elif 'common_period' in cell_value: # shortest recoverytime

            tmp.append('common_period')


        elif 'common_holding' in cell_value:
            tmp.append('common_holding')

        elif ('12_mo_yield' in cell_value) or ('12_month_yield' in cell_value):
            tmp.append('12_month_yield')

        elif ("turnover" in cell_value):
            tmp.append('turn_over')

        elif ("active_share" in cell_value) or ("activeshare" in cell_value):
            tmp.append("active_share")

        elif ("morning_star" in cell_value) or ("morningstar" in cell_value):
            tmp.append("morning_star")
        else:
            tmp.append(cell_value)

        #global columns
        #for other_company in columns:
        for other_company in header_columns:
            tmp += [row[other_company]]
        new_data.append(tmp)

    #columns = ['compare']+columns
    columns = ['compare']+header_columns
    updated_df = pd.DataFrame(new_data , columns=columns)
    return updated_df

def generate_documents(main_df,pair_company,document):

    """
    @@ function take two company dataframe and header of two company_name
    and docx file obj and check all the condition and generate summary.
    """

    columns = pair_company



    """"Performance"""
    performance_list = ['1_year','3_year','5_Year','sharpe_ratio','std_dev','ranking','alpha']
    performance_list_flag = []
    performance_dict = {}

    """"Drawdown"""

    drawdown_analysis_list = ['max_drawdown','shortest_recovery_time','recovery_time','common_period']
    drawdown_analysis_list_flag = []
    drawdown_dict = {}

    """Common holdings"""
    common_holding_analysis_list = ['common_holding']
    common_holding_analysis_list_flag = []
    common_holding_dict = {}


    """12 months yield"""

    months_yields_list = ['12_month_yield']
    months_yields_list_flag = []
    months_yields_dict  = {}

    """ turn over """

    turn_over_list = ['turn_over']
    turn_over_list_flag = []
    turn_over_dict      = {}

    """ Active Share"""

    active_share_list = ["active_share"]
    active_share_list_flag = []
    active_share_dict    = {}


    """Morning Star """
    morning_star_list = ["morning_star"]
    morning_star_list_flag = []
    morning_star_dict = {}


    flag_list = performance_list_flag + drawdown_analysis_list_flag + months_yields_list_flag + turn_over_list_flag + active_share_list_flag + morning_star_list_flag
    attribute_list = performance_list + drawdown_analysis_list + common_holding_analysis_list + months_yields_list + turn_over_list + active_share_list + morning_star_list


    #sys.exit()

    for indx , row in main_df.iterrows():

        value1  = row[columns[0]]
        value2  = row[columns[1]]
        value3  = row[columns[2]]
        #print ("value1:::::::::", value1)
        value1 = "_".join(value1.split(" "))
        #print ("updated_value1::::", value1)
        #continue

        if value1 in attribute_list:
            if value1 in flag_list:
                continue
            if (value2 < value3):
                 #print ("Rahulvalue2==========" ,value1 , value2 , value3)

                 if value1 in  ['1_year','3_year','5_year','sharpe_ratio','alpha','ranking']:
                     performance_dict[value1] = True
                     performance_list_flag.append(value1)

                 elif value1 in ['common_period']:
                     drawdown_dict[value1] = [True , value2 , value3]
                     drawdown_analysis_list_flag.append(value1)

                 elif value1 in ['common_holding']:

                     common_holding_dict[value1] = True
                     common_holding_analysis_list_flag.append(value1)

                 elif value1 in ['12_month_yield']:

                     #print ("month_yield::::", value1)
                     months_yields_dict[value1] = [True , value2 , value3]
                     months_yields_list_flag.append(value1)

                 elif value1 in ["active_share"]:
                     active_share_dict[value1] = [True , value2 ,value3]
                     active_share_list_flag.append(value1)

                 elif value1 in ["morning_star"]:
                     morning_star_dict[value1] = [True , value2 , value3]
                     morning_star_list_flag.append(value1)


            elif (value2 > value3):
                #print ("Rahulvalue1========", value1 , value2 , value3)
                if value1 in ['std_dev']:
                    performance_dict[value1] = True
                    performance_list_flag.append(value1)


                elif value1 in ['max_drawdown','shortest_recovery_time','recovery_time']:
                    print ("I am Here..")

                    drawdown_dict[value1] = [True,value2,value3 ]
                    drawdown_analysis_list_flag.append(value1)

                elif value1 in ["turn_over"]:
                    turn_over_dict[value1] = [True,value2,value3]
                    turn_over_list_flag.append(value1)

                elif value1 in ["morning_star"]:
                    morning_star_dict[value1] = [True , value2 , value3]
                    morning_star_list_flag.append(value1)



    str_header  = ''
    str_header += "%s vs %s Positioning Points\n" %(columns[1], columns[2])
    print (str_header)

    document.add_heading(str_header, level=1)

    str1 = ""
    str1 += "Performance:\n"


    p = document.add_paragraph(style='ListBullet')

    p.add_run("Performance: ").bold = True


    if  '1_year' in performance_dict and '3_year' in performance_dict and '5_year' in performance_dict:
        str1 += "The %s outperforms %s on an absolute & risk adjusted basis for 1, 3, & 5 yr time periods." %(columns[2],columns[1])
        p.add_run("The %s outperforms %s on an absolute & risk adjusted basis for 1, 3, & 5 yr time periods." %(columns[2],columns[1]))


    elif  '1_year' in performance_dict and '3_year' in performance_dict :
        str1 += "The %s outperforms %s on an absolute & risk adjusted basis for 1,& 3 yr time periods." %(columns[2],columns[1])
        p.add_run("The %s outperforms %s on an absolute & risk adjusted basis for 1,& 3 yr time periods." %(columns[2],columns[1]))


    elif  '1_year' in performance_dict and '5_year' in performance_dict :
        str1 += "The %s outperforms %s on an absolute & risk adjusted basis for 1, & 5 yr time periods." %(columns[2],columns[1])
        p.add_run("The %s outperforms %s on an absolute & risk adjusted basis for 1, & 5 yr time periods." %(columns[2],columns[1]))


    elif  '3_year' in performance_dict and '5_year' in performance_dict :
        str1 += "The %s outperforms %s on an absolute & risk adjusted basis for 3, & 5 yr time periods." %(columns[2],columns[1])
        p.add_run("The %s outperforms %s on an absolute & risk adjusted basis for 3, & 5 yr time periods." %(columns[2],columns[1]))


    elif  '1_year' in performance_dict :
        str1 += "The %s outperforms %s on an absolute & risk adjusted basis for 1 yr. time period." %(columns[2],columns[1])
        p.add_run("The %s outperforms %s on an absolute & risk adjusted basis for 1 yr. time period." %(columns[2],columns[1]))


    elif '3_year' in performance_dict:
        str1 += "The %s outperforms %s on an absolute & risk adjusted basis for 3 yr. time  period." %(columns[2],columns[1])
        p.add_run("The %s outperforms %s on an absolute & risk adjusted basis for 3 yr. time  period." %(columns[2],columns[1]))


    elif '5_year' in performance_dict:
        str1 += "The %s outperforms %s on an absolute & risk adjusted basis for 5 yr. time  period." %(columns[2],columns[1])
        p.add_run("The %s outperforms %s on an absolute & risk adjusted basis for 5 yr. time  period." %(columns[2],columns[1]))


    if 'sharpe_ratio' in performance_dict:
        str1 += "%s has higher Sharpe Ratio "  %(columns[2])
        p.add_run("%s has higher Sharpe Ratio "  %(columns[2]))


    if 'std_dev' in performance_dict:
        str1 += " combined with a lower std deviation "
        p.add_run(" combined with a lower std deviation ")


    if 'alpha' in performance_dict:
        str1 += " and higher alpha ratio."
        p.add_run(" and higher alpha ratio.")


    print (str1)



    str2 = ""

    str2 = "Drawdown Analysis:\n"


    if drawdown_dict:

        p1 = document.add_paragraph(style='ListBullet')

        p1.add_run("Drawdown Analysis: ").bold = True

    #print (drawdown_dict)
    #sys.exit()

    if 'max_drawdown' in drawdown_dict :
        str2 += " %s offers better downside protection with a lower max drawdown %s " %(columns[2],"%")
        p1.add_run(" %s offers better downside protection with a lower max drawdown %s " %(columns[2],"%"))

    if 'shortest_recovery_time' in drawdown_dict:
         str2 += "and a shorter recovery time (%s %s %s vs %s %s %s)" %(columns[2],drawdown_dict['shortest_recovery_time'][2],'%',columns[1],drawdown_dict['shortest_recovery_time'][1],'%')
         p1.add_run("and a shorter recovery time (%s %s %s vs %s %s %s)" %(columns[2],drawdown_dict['shortest_recovery_time'][2],'%',columns[1],drawdown_dict['shortest_recovery_time'][1],'%'))

    if 'common_period' in drawdown_dict:
         str2 +=  "(Longest common period: %s: %s %s vs %s %s)." % (columns[2],drawdown_dict['common_period'][2],'%',drawdown_dict['common_period'][1],'%')
         p1.add_run("(Longest common period: %s: %s %s vs %s %s)." % (columns[2],drawdown_dict['common_period'][2],'%',drawdown_dict['common_period'][1],'%'))

    print (str2)


    #print (common_holding_dict)

    str3 = ""

    if "common_holding in common_holding_dict:
        str3 += "Commn Holding :\n"
        str3  += "%s have more Common holding in compare to %s" %(columns[2],columns[1])

        p2 = document.add_paragraph(style='ListBullet')
        p2.add_run("Common Holding: ").bold = True

        p2.add_run("%s have more Common holding in compare to %s" %(columns[2],columns[1]))

    print (str3)


    #print (months_yields_dict)

    """"12 months yields """

    str4 = ""

    if "12_month_yield" in months_yields_dict:

        str4 = "%s has higher 12 Month Yield\n: %s's dividend focus offers investors the additional beneﬁt ofa %s %s yield vs. %s %s %s" %(columns[2],columns[2],months_yields_dict['12_month_yield'][2],'%',columns[1],months_yields_dict['12_month_yield'][1],'%')

        p3 = document.add_paragraph(style='ListBullet')
        p3.add_r


    str5 = ""

    #print ("Turn_Over_dict::::" ,turn_over_dict)

    if "turn_over" in turn_over_dict:


        str5 = "%s has Lower Turnover \n: %s: %s %s vs. : %s %s; SMID’s lower turnover may be beneﬁcial for tax sensitive investors." %(columns[2],columns[2],turn_over_dict['turn_over'][2],'%',turn_over_dict['turn_over'][1],'%')

        p4 = document.add_paragraph(style='ListBullet')
        p4.add_run("%s has Lower Turnover :" %(columns[2])).bold = True
        p4.add_run("%s: %s %s vs. : %s %s; SMID’s lower turnover may be beneﬁcial for tax sensitive investors." %(columns[2],turn_over_dict['turn_over'][2],'%',turn_over_dict['turn_over'][1],'%'))

    print (str5)



    str6 = ""

    if "active_share" in active_share_dict:
        str6 += "Active Share %:"
        str6 += " %s active share is around %s %s . %s active share is %s %s" %(columns[2],active_share_dict['active_share'][2],'%',columns[1],active_share_dict['active_share'][1],'%')

        p5 = document.add_paragraph(style='ListBullet')
        p5.add_run("Active Share %: ").bold = True
        p5.add_run(" %s active share is around %s %s . %s active share is %s %s" %(columns[2],active_share_dict['active_share'][2],'%',columns[1],active_share_dict['active_share'][1],'%'))


    print (str6)


    str7 = ""


    if "morn or columnsing_star" in morning_star_dict:

        str7 += "M* Star Rating: "
        str7 +=  " %s M*star rating is %s vs. %s %s stars " %(columns[2], morning_star_dict['morning_star'][2],columns[1],morning_star_dict['morning_star'][1])

        p6 = document.add_paragraph(style='ListBullet')
        p6.add_run("M* Star Rating: ").bold = True
        p6.add_run(" %s M*star rating is %s vs. %s %s stars " %(columns[2], morning_star_dict['morning_star'][2],columns[1],morning_star_dict['morning_star'][1]))


def main_Handler(file_name):

    main_dataFrame,header_columns = read_excel_sheet(file_name)
    result = pd.concat(main_dataFrame)
    """
    Repalce all na with 0 and transpose the DataFrame and save into csv file.
    """
    result = result.fillna(0)
    result = result[(result.T != 0).any()]
    result = result.loc[:, (result != 0).any(axis=0)]
    result = result.select(lambda x: not re.search('diff', x), axis=1)
    result = result.fillna(0)
    pd.options.display.float_format = '{:.2f}'.format
    result.to_csv(file_name[:-4] + "_Output1.csv")
    updated_df = renaming_rows_name(file_name,header_columns)

    comparison_list = []
    main_company = list(filter(lambda x: 'principal' in x.lower(), header_columns))

    for company_name in header_columns:
        if company_name not in main_company:
            comparison_list.append(['compare',company_name,main_company[0]])


    document = Document()

    for  pair_company in comparison_list:
        #print ("Pair-Company:::::::" ,updated_df[pair_company])
        generate_documents(updated_df[pair_company],pair_company,document)

    print ("Final-Report:::::::" ,'%s_report.docx' %(file_name[:-4]))
    document.save('%s_report.docx' %(file_name[:-4]))

if __name__ == "__main__":
    file_name = "SMID vs GSCIX 8.31.2017.xls"
    #file_name = "International Fund vs Top Competitors.xls"
    #file_name = "Blue Chip vs Top Competitors 1.31.2018.xls"
    main_Handler(file_name)
